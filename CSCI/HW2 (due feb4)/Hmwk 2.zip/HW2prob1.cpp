// Author: Karan Sharma CS1300 Spring 2018
// Recitation: 101 – Akriti Kapur
// Cloud9 Workspace Editor Link: https://ide.c9.io/kash0329/karansharma-csci1300
// Homework 2 - Problem #1
#include <stdio.h>
#include <iostream>

using namespace std;

/**
* Algorithm: calculates population after a year through the addition and subtraction of other rates
*   1. calculate birthrate aka number born in a year
*   2. calculate deathrate aka number dead in a year
*   3. calculate immigration rate aka number immigrating in a year
*   4. calculate population in a year by summing all values but subtracting dead from total
*   Input parameters: integer value for population
*   Output: numeric population after a year 
*   Returns: yearPopulation
*/

// return_type funcname (parameters) { }
int population(int pop) 
{

    int birthRate = (60*60*24*365)/8; //number born in a year
	int deathRate = (60*60*24*365)/12; //number dead in a year
	int immigrationRate = (60*60*24*365)/33; //number immigrating in a year
	int yearPopulation = (pop + birthRate + immigrationRate) - deathRate; //sum all values with user input
	return yearPopulation;
}

int main() 
{
    int pop;
    cin >> pop;
    cout << population(pop) << endl; //print parsed function
    return 0;
}
