// Author: Karan Sharma CS1300 Spring 2018
// Recitation: 101 – Akriti Kapur
// Cloud9 Workspace Editor Link: https://ide.c9.io/kash0329/karansharma-csci1300
// Homework 2 - Problem #2
#include <stdio.h>
#include <iostream>

using namespace std;

/**
* Algorithm: calculates number of days hours minutes and seconds given a total number of seconds
*   1. calculate total seconds converted into a trunkated number of days
*   2. calculate total seconds to hours - days in hours
*   3. calculate total seconds in minutes - hours in minutes - days in minutes
*   4. calculate total seconds - other values in seconds
*   Input parameters: integer value for total seconds
*   Output: days hours minutes and seconds 
*   Returns: nothing
*/

// return_type funcname (parameters) { }
void howLong(int secondsGiven) 
{

	int days = secondsGiven/(60*60*24); //total seconds converted into a trunkated number of days

	int hours = (secondsGiven/(60*60)-(days*24)); //total seconds to hours - days in hours

	int minutes = (secondsGiven/(60)-(hours*60)-(days*60*24)); //total seconds in minutes - hours in minutes - days in minutes

	int seconds = (secondsGiven-(minutes*60)-(hours*60*60)-(days*60*60*24)); //total seconds - other values in seconds

	cout << secondsGiven << " seconds is " << days << " days, " << hours << " hours, " << minutes << " minutes, and " << seconds << " seconds." << endl;
}

int main() 
{
	int secondsGiven;
	cin >> secondsGiven; 
	howLong(secondsGiven); 
    return 0;
}
