// Author: Karan Sharma CS1300 Spring 2018
// Recitation: 101 – Akriti Kapur
// Cloud9 Workspace Editor Link: https://ide.c9.io/kash0329/karansharma-csci1300
// Homework 2 - Problem #3
#include <stdio.h>
#include <iostream>

using namespace std;

/**
* Algorithm: calculates Carnot efficiency given absolute temperatures
*   1. calculate n treating tC and tH as float values
*   2. float function so returns decimal instead of 1
*   Input parameters: integer value for tC and tH
*   Output: Carnot efficiency value 
*   Returns: value of carnot efficiency
*/

// return_type funcname (parameters) { }
float carnot(int tC, int tH) 
{
    float n = (1 - ((float) tC)/((float) tH)); //calculate n treating tC and tH as float values
    return n;
    //float function so returns decimal instead of 1
}

int main() 
{
	int tC;
	int tH;
	
	cout << "tC?" << endl;
	cin >> tC;
	
	cout << "tH?" << endl;
	cin >> tH; 
	
	cout << carnot(tC, tH) << endl;
	
    return 0; //stop program
}