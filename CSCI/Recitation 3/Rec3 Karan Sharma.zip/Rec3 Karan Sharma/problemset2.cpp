#include <stdio.h>
#include <iostream>

using namespace std;

float calcPay(float hours, float rate)
{
    float pay = hours * rate;
    return pay;
}

int main () 
{
    cout << calcPay(6,9) << endl;
}