#include <stdio.h>
#include <iostream>

using namespace std;

float printPay(float pay)
{

    cout << "Your pay is " << pay << endl;
}

int main () 
{
    printPay(60);
    return 0;
}