#include <stdio.h>
#include <iostream>

using namespace std;


// return_type funcname (parameters) { }
float getHours() 
{
    float hours;
    cout << "Please enter how many hours you worked this week:" << endl;
    cin >> hours;
    return hours;
}

int main() 
{
    cout << getHours() << endl;
    return 0;
}


