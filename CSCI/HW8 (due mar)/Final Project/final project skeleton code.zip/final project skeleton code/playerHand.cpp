#include <iostream>
#include <tuple>
#include <limits>
#include <fstream>
#include <stdexcept>
#include <string>
#include <sstream>
#include <math.h>
#include <stdlib.h>

using namespace std;

class Player
{
    private:
        Card currCard;
    public:
        Player(){
            currCard = NULL;  
        };
        
        //getters and setters to obtain players's card
        void setCard(Card card){
            this->currCard = card;
        };
        
         Card getCard(){
            return currCard; 
        };
        
        void genCardIndex(Card card){
              //creates an array of objects for card 1, card 2, and card 3
        };
        
};

int main()
{
    
}