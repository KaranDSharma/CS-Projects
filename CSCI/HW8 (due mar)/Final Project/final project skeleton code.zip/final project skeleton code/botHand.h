#ifndef botHand
#define botHand

#include <iostream>
#include <tuple>
#include <limits>
#include <fstream>
#include <stdexcept>
#include <string>
#include <sstream>
#include <math.h>
#include <stdlib.h>


using namespace std;

class Bot
{
    private:
        Card currCard;
    public:
        Bot();
        //getters and setters to obtain bot's card
        void setCard(Card card);
        Card getCard();

};

#endif