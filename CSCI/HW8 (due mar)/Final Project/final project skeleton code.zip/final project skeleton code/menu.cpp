#include <iostream>
#include <tuple>
#include <limits>
#include <fstream>
#include <stdexcept>
#include <string>
#include <sstream>
#include <math.h>
#include <stdlib.h>

using namespace std;

class Menu
{
    private:
        Bot bot;
        Player player;
    public:
        int prompt(int input){
            //bool x = false;
            // while(false)
            // prompts user to either draw card, lock card (1 2 or 3), or repeat existing stats -(1,2,3)
            // if invalid input alerts for invalid input
            // when 2 selected, x = true and breaks out of loop 
            // conducts comparison of cards:
            // if both cards have equal stats, discard both cards, both players get a point, and restart the round
            // if both cards have lower hp values than the opponent's attack value, discard both cards, neither player gets a point, and restart the round
            // if both cards have lower attack values then the opponent's HP value, x = false
            // while(false)
            // draw another card and add said card's stats to existing card
            // compare stats again, if both cards have lower attack values then the opponent's HP value, x = false, else x = true and breaks out of loop
            // return int score
        };
        
        void saveCards(string fileName){
            // writes bot object containing bot card info to file
            // writes player object containing player card info to file
        };
};

int main()
{
    
}