#include <iostream>
#include <tuple>
#include <limits>
#include <fstream>
#include <stdexcept>
#include <string>
#include <sstream>
#include <math.h>
#include <stdlib.h>

using namespace std;

class Bot
{
    private:
        Card currCard;
    public:
        Bot(){
            currCard = NULL;  
        };
        
        //getters and setters to obtain bot's card
        void setCard(Card card){
            this->currCard = card;
        };
        
         Card getCard(){
            return currCard; 
        };

        
};
       

int main()
{
    
}