#ifndef playerHand
#define playerHand

#include <iostream>
#include <tuple>
#include <limits>
#include <fstream>
#include <stdexcept>
#include <string>
#include <sstream>
#include <math.h>
#include <stdlib.h>


using namespace std;

class Player
{
    private:
        Card currCard;
    public:
        Player();
        //getters and setters to obtain players's card
        void setCard(Card card);
        Card getCard();
        void genCardIndex(Card card);
        
};

#endif