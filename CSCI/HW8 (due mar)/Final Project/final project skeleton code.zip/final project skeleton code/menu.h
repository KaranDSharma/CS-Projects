#ifndef menu
#define menu

#include <iostream>
#include <tuple>
#include <limits>
#include <fstream>
#include <stdexcept>
#include <string>
#include <sstream>
#include <math.h>
#include <stdlib.h>


using namespace std;

class Menu
{
    private:
        Bot bot;
        Player player;
    public:
        int prompt(int input);
        void saveCards(string fileName);
};

#endif