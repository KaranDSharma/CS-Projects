#ifndef UI
#define UI

#include <iostream>
#include <tuple>
#include <limits>
#include <fstream>
#include <stdexcept>
#include <string>
#include <sstream>
#include <math.h>
#include <stdlib.h>


using namespace std;

class Interface
{
    public:
        void interface(int score, int atk, int hp, bool joust);
};

#endif