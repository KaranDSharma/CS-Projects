#include <iostream>
#include <tuple>
#include <limits>
#include <fstream>
#include <stdexcept>
#include <string>
#include <sstream>
#include <math.h>
#include <stdlib.h>

using namespace std;

class Interface
{
    public:
        void interface(int score, int atk, int hp, bool joust){
            // print duel phase animation
            // prints score to center of screen, attack and HP onto card
            // if joust is false, prints duel to center of screen
            if(joust){
                // print joust phase animation, and joust to center of screen
                // prints score to center of screen, attack and HP onto card
            }
        };
};

int main()
{
    
}