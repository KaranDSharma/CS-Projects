#include <iostream>
#include <tuple>
#include <limits>
#include <fstream>
#include <stdexcept>
#include <string>
#include <sstream>
#include <math.h>
#include <stdlib.h>

using namespace std;

class Card
{
    private: 
        int cardAtk;
        int cardHp;
        
        int randLength;
        int buffer;
        string randConsonant;
        string randVowel;
        string cardName;
        
    public:
        Card()
        {
            //randomly generates stats
            srand(time(NULL));
            cardAtk = rand() % 9 + 1;
            cardHp = rand() % 9 + 1;
            //alternates consonants and vowels for name
            string vowel[5] = {"a","e","i","o","u"};
            string consonant[21] = {"b","c","d","f","g","h","j","k","l","m","n","p","q","r","s","t","v","w","x","y","z"};
            randLength = rand() % 4 + 2;
            
            for(int i=0; i<randLength;i++)
            {
                buffer = rand() % 21;
                randConsonant = consonant[buffer];
                cardName.append(randConsonant);
                
                buffer = rand() % 5;
                randVowel = vowel[buffer];
                cardName.append(randVowel);
            }
            
        };
        
        ~Card()
        {
            cardAtk = 0;
            cardHp = 0;
            cardName = "";
        }
        
        int getCardAtk()
        {
            return cardAtk;
        }
        
        void setCardAtk(int atk)
        {
            cardAtk = atk;
        }
        
        int getCardHp()
        {
            return cardHp;
        }
        
        void setCardHp(int hp)
        {
            cardHp = hp;
        }
    
        string getCardName()
        {
            return cardName;
        }
        
        void setCardName(string name)
        {
            cardName = name;
        }
};

int main()
{
    /*Card newCard;
    cout<<newCard.getCardName()<<endl;
    cout<<newCard.getCardAtk()<<endl;
    cout<<newCard.getCardHp();*/
}